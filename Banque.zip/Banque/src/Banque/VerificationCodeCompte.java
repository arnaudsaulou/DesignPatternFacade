package Banque;

public class VerificationCodeCompte {

    private final static int CODE_COMPTE = 666;

    private static int getCodeCompte(){
        return  CODE_COMPTE;
    }

    public boolean codeCompteOk(int codeCompteATest){
        return codeCompteATest == getCodeCompte();
    }
}
