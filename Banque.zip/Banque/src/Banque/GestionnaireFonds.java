package Banque;

public class GestionnaireFonds {

    private double fondDisponibleSurLeCompte = 10000.0;
    private double plafondSurLeCompte = 100000.0;

    public double getFondDisponibleSurLeCompte() {
        return fondDisponibleSurLeCompte;
    }

    public double getPlafondSurLeCompte() {
        return plafondSurLeCompte;
    }

    public void enleverMontantSurLeCompte(double montantRetrait) {
        fondDisponibleSurLeCompte -= montantRetrait;
    }

    public void ajouterMontantSurLeCompte(double montantDepot) {
        fondDisponibleSurLeCompte += montantDepot;
    }
}
