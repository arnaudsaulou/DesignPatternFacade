package Banque;

public class VerificationFonds {

    private GestionnaireFonds gestionnaireFonds;

    public VerificationFonds(GestionnaireFonds gestionnaireFonds) {
        this.gestionnaireFonds = gestionnaireFonds;
    }

    public boolean isRetraitPossible(double montantRetrait) {
        if (montantRetrait > this.gestionnaireFonds.getFondDisponibleSurLeCompte()) {

            System.out.println("Retrait impossible !");

            return false;
        } else {

            System.out.println("Retrait effectué !");


            return true;
        }
    }

    public boolean isDepotPossible(double montantDepot) {
        if (montantDepot + this.gestionnaireFonds.getFondDisponibleSurLeCompte() >
                this.gestionnaireFonds.getPlafondSurLeCompte()) {

            System.out.println("Depot impossible !");

            return false;
        } else {

            System.out.println("Depot effectué !");

            return true;
        }
    }
}
