package Banque;

public class VerificationNumeroCompte {

    private final static int NUMERO_COMPTE = 123456;

    private static int getNumeroCompte() {
        return NUMERO_COMPTE;
    }

    public boolean numeroCompteOK(int numeroCompteATest) {
        return numeroCompteATest == getNumeroCompte();
    }
}
