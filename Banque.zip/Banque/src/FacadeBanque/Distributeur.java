package FacadeBanque;

import Banque.GestionnaireFonds;
import Banque.VerificationCodeCompte;
import Banque.VerificationFonds;
import Banque.VerificationNumeroCompte;

public class Distributeur {

    private int numeroCompte;
    private int codeCompte;

    private VerificationNumeroCompte verificationNumeroCompte;
    private VerificationCodeCompte verificationCodeCompte;
    private VerificationFonds verificationFonds;
    private GestionnaireFonds gestionnaireFonds;

    public Distributeur(int numeroCompte, int codeCompte) {
        this.numeroCompte = numeroCompte;
        this.codeCompte = codeCompte;
        this.verificationNumeroCompte = new VerificationNumeroCompte();
        this.verificationCodeCompte = new VerificationCodeCompte();
        this.gestionnaireFonds = new GestionnaireFonds();
        this.verificationFonds = new VerificationFonds(this.gestionnaireFonds);

        afficherMessageBienvenue();
    }

    private void afficherMessageBienvenue() {
        System.out.println("Bienvenue à la banque Blasquez");
        System.out.println("Nous serons heureux de vous donner votre argent si nous la trouvons !");
    }

    public int getNumeroCompte() {
        return numeroCompte;
    }

    public int getCodeCompte() {
        return codeCompte;
    }

    public void retirerArgent(double montantRetrait) {
        if (this.verificationNumeroCompte.numeroCompteOK(this.getNumeroCompte()) &&
                this.verificationCodeCompte.codeCompteOk(this.getCodeCompte()) &&
                this.verificationFonds.isRetraitPossible(montantRetrait)) {

            this.gestionnaireFonds.enleverMontantSurLeCompte(montantRetrait);
        }


    }

}
