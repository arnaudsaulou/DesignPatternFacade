import FacadeBanque.Distributeur;

public class Client {

    public static void main(String[] args){

        Distributeur distributeur = new Distributeur(123456,666);

        distributeur.retirerArgent(100000.0);

        distributeur.deposerArgent(90000.1);

        distributeur.deposerArgent(90000.0);

        distributeur.retirerArgent(100000.0);

        distributeur.retirerArgent(1.0);
    }
}
